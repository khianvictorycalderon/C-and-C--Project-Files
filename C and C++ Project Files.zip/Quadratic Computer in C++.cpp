#include <iostream>
#include <Math.h>
using namespace std;
double a, b, c, r1, r2;

int main() {
	cout << "Quadratic Computer in C++ \nBy Khian Victory D. Calderon \n\n";
    cout << "Enter the 3 input from the quadratic equation: \n";
    cin >> a;
    cin >> b;
    cin >> c;
    r1 = ((b * -1) + sqrt((b * b) - (4 * a * c))) / (2 * a);
    r2 = ((b * -1) - sqrt((b * b) - (4 * a * c))) / (2 * a);
    cout << "The 2 answers from the quadratic equation are: \n";
    cout << r1 << " and " << r2 << "\n";
	system("pause");
}
