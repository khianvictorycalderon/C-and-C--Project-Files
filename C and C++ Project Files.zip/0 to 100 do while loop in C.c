#include <stdio.h>
// code by khian victory d calderon
int number = 0; // initialization
int main()
{
	do {
		printf("%d \n",number); // print
		number++; // increment
	}
	while(number<=100); // post condition
	printf("Numbers Printed!");
	getchar(); //prevent console from closing
}
