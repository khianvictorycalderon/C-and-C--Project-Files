#include <stdio.h>
float n,p,f;
// n = number , p = percentage , f = formula
int main() {
 printf("\nEnter Percentage: \n");
 scanf("%f",&p);
 printf("Enter Number: \n");
 scanf("%f",&n);
 f = (n * p)/100.0f;
 printf("%.2f percent of %.2f is %.2f \n",p,n,f);
 system("pause");
}
