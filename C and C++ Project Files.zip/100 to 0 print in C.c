//code by Khian Calderon
#include <stdio.h>
int y = 100;
int main()
{
	while(y>=0) // condition
	{
		printf("%d \n",y);// print numbers
		y--; // decrease by one
	}
	printf("Code by Khian , thanks for testing");
	getchar(); // prevent console from closing
}
