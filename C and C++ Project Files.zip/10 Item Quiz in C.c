#include <stdio.h>
#include <string.h>
int score = 0;
int main()
{
	char z[1];
	printf("***Welcome to 1 - 10 Random Quiz*** \n");
	printf("Press Enter to get Started! \n \n");
	getchar();
	
	//---------
	printf(" Q: Who was the person killed that started World War 1? \n");
    printf(" A. Franz Frietkrieg \n");
    printf(" B. Franz Ferdinand \n");
    printf(" C. Franz Napoleon \n");
    printf(" D. Deucthe Frendiaz \n");
    printf("\n Your answer is letter : \n ");
    reanswer1 : 
	scanf("%s",z);
	if (strcmp(z,"b")==0||strcmp(z,"B")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer1;
	}
	
	//---------
	printf(" Q: When was world war 2 started? \n");
    printf(" A. September 1,1939 \n");
    printf(" B. September 2,1939 \n");
    printf(" C. September 13,1939 \n");
    printf(" D. September 25,1939 \n");
    printf("\n Your answer is letter : \n ");
    reanswer2 : 
	scanf("%s",z);
	if (strcmp(z,"a")==0||strcmp(z,"A")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer2;
	}
	
	//---------
	printf(" Q: Who was the leader of Nazi Germany? \n");
    printf(" A. Franz Ferdinand \n");
    printf(" B. Yuri Gagarin \n");
    printf(" C. Adolf Hitler \n");
    printf(" D. Benito Mussolini \n");
    printf("\n Your answer is letter : \n ");
    reanswer3 : 
	scanf("%s",z);
	if (strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer3;
	}
	
	//---------
	printf(" Q: Who was the leader of the Soviet Union during World War 2? \n");
    printf(" A. Joseph Stalin \n");
    printf(" B. Josef Volvogran \n");
    printf(" C. Vladimir Lenin \n");
    printf(" D. Katchuyt Lenina \n");
    printf("\n Your answer is letter : \n ");
    reanswer4 : 
	scanf("%s",z);
	if (strcmp(z,"a")==0||strcmp(z,"A")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer4;
	}
	
	//---------
	printf(" Q: Where was the Pearl Harbor Attack Happened? \n");
    printf(" A. Coast of Philippines \n");
    printf(" B. Papua New Guinea \n");
    printf(" C. Madagascar \n");
    printf(" D. Hawaii \n");
    printf("\n Your answer is letter : \n ");
    reanswer5 : 
	scanf("%s",z);
	if (strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"a")==0||strcmp(z,"A")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer5;
	}
	
	//---------
	printf(" Q: When was pearl harbor bombed? \n");
    printf(" A. December 7, 1940 \n");
    printf(" B. December 17, 1941 \n");
    printf(" C. December 7, 1941 \n");
    printf(" D. December 17, 1940 \n");
    printf("\n Your answer is letter : \n ");
    reanswer6 : 
	scanf("%s",z);
	if (strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer6;
	}
	
	//---------
	printf(" Q: Who was the emperor of japan during world war 2? \n");
    printf(" A. Hirohito \n");
    printf(" B. Akihito \n");
    printf(" C. Taisho \n");
    printf(" D. Hideki \n");
    printf("\n Your answer is letter : \n ");
    reanswer7 : 
	scanf("%s",z);
	if (strcmp(z,"a")==0||strcmp(z,"A")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer7;
	}
	
	//---------
	printf(" Q: When was hiroshima bombed? \n");
    printf(" A. August 9, 1945 \n");
    printf(" B. August 8, 1945 \n");
    printf(" C. August 5, 1945 \n");
    printf(" D. August 6, 1945 \n");
    printf("\n Your answer is letter : \n ");
    reanswer8 : 
	scanf("%s",z);
	if (strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer8;
	}
	
	//---------
	printf(" Q: When was operation barbarossa launched? \n");
    printf(" A. July 22, 1941 \n");
    printf(" B. June 22, 1941 \n");
    printf(" C. July 12, 1941 \n");
    printf(" D. June 12, 1941 \n");
    printf("\n Your answer is letter : \n ");
    reanswer9 : 
	scanf("%s",z);
	if (strcmp(z,"b")==0||strcmp(z,"B")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer9;
	}
	
	//---------
	printf(" Q: When did world war 2 ended? \n");
    printf(" A. September 6, 1945 \n");
    printf(" B. September 2, 1944 \n");
    printf(" C. September 2, 1945 \n");
    printf(" D. September 5, 1945 \n");
    printf("\n Your answer is letter : \n ");
    reanswer10 : 
	scanf("%s",z);
	if (strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer10;
	}
	
	//---------
	printf("Thanks for testing this beta project! , Your score is %d / 10 \n \n",score);
	system("pause");
	getchar();
    return 0;
}


/*

    if a is the answer : 
    //---------
	printf(" Q:  \n");
    printf(" A.  \n");
    printf(" B.  \n");
    printf(" C.  \n");
    printf(" D.  \n");
    printf("\n Your answer is letter : \n ");
    reanswer : 
	scanf("%s",z);
	if (strcmp(z,"a")==0||strcmp(z,"A")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer;
	}
	
	if b is the answer : 
	//---------
	printf(" Q:  \n");
    printf(" A.  \n");
    printf(" B.  \n");
    printf(" C.  \n");
    printf(" D.  \n");
    printf("\n Your answer is letter : \n ");
    reanswer : 
	scanf("%s",z);
	if (strcmp(z,"b")==0||strcmp(z,"B")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"c")==0||strcmp(z,"C")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer;
	}
	
	if c is the answer : 
	//---------
	printf(" Q:  \n");
    printf(" A.  \n");
    printf(" B.  \n");
    printf(" C.  \n");
    printf(" D.  \n");
    printf("\n Your answer is letter : \n ");
    reanswer : 
	scanf("%s",z);
	if (strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer;
	}
	
	if d is the answer : 
	//---------
	printf(" Q:  \n");
    printf(" A.  \n");
    printf(" B.  \n");
    printf(" C.  \n");
    printf(" D.  \n");
    printf("\n Your answer is letter : \n ");
    reanswer : 
	scanf("%s",z);
	if (strcmp(z,"d")==0||strcmp(z,"D")==0)
    {
         printf(" Correct! \n \n");
         score++;
    } else if (strcmp(z,"a")==0||strcmp(z,"A")==0||strcmp(z,"b")==0||strcmp(z,"B")==0||strcmp(z,"c")==0||strcmp(z,"C")==0)
    {
    	printf(" Wrong! , Nice Try! \n \n");
	} else {
		printf(" Please Enter a valid input! \n \n");
		goto reanswer;
	}

*/
