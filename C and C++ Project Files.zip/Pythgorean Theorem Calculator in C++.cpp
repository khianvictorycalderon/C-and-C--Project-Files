#include <iostream>
#include <cmath>
using namespace std;
float leg1,leg2,h;
char c[1];
int main() {
 begin:
 cout << "\nWhat would you like to solve? \n";
 cout << "a. Hypotenuse \n";
 cout << "b. Legs \n";
 cin >> c;
 if(c=="a") {
 	cout << "Enter leg 1 Value: \n";
 	cin >> leg1;
 	cout << "Enter leg 2 Value: \n";
 	cin >> leg2;
 	h = sqrt((leg1 * leg1) + (leg2 * leg2));
 	cout << "The hypotenuse is" << h;
 } else if (c=="b") {
 	cout << "Enter Hypotenuse Value: \n";
 	cin >> h;
 	cout << "Enter leg 1 Value: \n";
 	cin >> leg1;
 	leg2 = sqrt((h * h) - (leg1 * leg1));
 	cout << "The missing leg is" << leg2;
 } else {
 	cout << "Invalid input!, a or b only!";
 	goto begin;
 }
 system("pause");
}
