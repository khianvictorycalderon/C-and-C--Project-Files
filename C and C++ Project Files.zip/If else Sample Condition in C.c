#include <stdio.h>
int main()
{
	int age;
	printf("Please Enter Your Age \n");
	scanf("%d",&age);
	if(age>=18)
	{
		printf("You are eligible to vote \n");
	} else {
		printf("You are ineligible to vote \n");
	}
	system("pause");
}
