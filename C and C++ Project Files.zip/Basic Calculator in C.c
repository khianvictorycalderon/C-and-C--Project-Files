#include<stdio.h>
#include <string.h>
int first_input;
int last_input;
int result;
char operation[1];
int main()
{
    printf("\n \n Enter your first input number \n \n");
    scanf("%d",&first_input);
    begin :
    printf("\n What operation should be use?");
    printf("\n to add , Enter + ");
    printf("\n to subtract , Enter -");
    printf("\n to multiply , Enter *");
    printf("\n to divide , Enter / \n \n");
	scanf("%s",operation);
    if (strcmp(operation,"+")==0 || strcmp(operation,"-")==0 
	|| strcmp(operation,"*")==0 || strcmp(operation,"/")==0)
    { goto proceed; } else {
    	printf("\n Sorry Invalid input , please enter again \n");
        goto begin;
	}
    proceed : 
    printf("\n Enter your last input \n \n");
    scanf("%d",&last_input);
    if (strcmp(operation,"+")==0)
    {
        result = first_input + last_input;
        printf("\n %d Plus %d is %d \n",
		first_input,last_input,result);
    } else if (strcmp(operation,"-")==0)
    {
        result = first_input - last_input;
        printf("\n %d Minus %d is %d \n",
		first_input,last_input,result);
    } else if (strcmp(operation,"*")==0)
    {
        result = first_input * last_input;
        printf("\n %d Times %d is %d \n",
		first_input,last_input,result);
    } else if (strcmp(operation,"/")==0)
    {
        result = first_input / last_input;
        printf("\n %d Divided by %d is %d \n",
		first_input,last_input,result);
    }
    system("pause");
}











