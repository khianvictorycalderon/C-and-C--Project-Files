#include <iostream>
using namespace std;
int IC; // Input Count, How many inputs? how many choices?
int st; // status, if the user want to do it again or exit
int main() {
	cout << "\n Weighted Mean Calculator Table in C++ \n";
	cout << " by Khian Victory D. Calderon \n";
	terminal1:
	cout << " How many choices in the questions? (2 - 10 Only) \n";
	cin >> IC;
	terminal2:
	if(IC==2) {
		float ch1, ch2, a1, a2, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		terminal3A:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		r = ((ch1 * a1) + (ch2 * a2)) / (a1 + a2);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==3) {
		float ch1, ch2, ch3, a1, a2, a3, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		terminal3B:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3)) / (a1 + a2 + a3);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==4) {
		float ch1, ch2, ch3, ch4, a1, a2, a3, a4, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		terminal3C:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4)) / (a1 + a2 + a3 + a4);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==5) {
		float ch1, ch2, ch3, ch4, ch5, a1, a2, a3, a4, a5, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		terminal3D:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5)) / (a1 + a2 + a3 + a4 + a5);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==6) {
		float ch1, ch2, ch3, ch4, ch5, ch6, a1, a2, a3, a4, a5, a6, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		cin >> ch6;
		terminal3E:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		cin >> a6;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6)) / (a1 + a2 + a3 + a4 + a5 + a6);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==7) {
		float ch1, ch2, ch3, ch4, ch5, ch6, ch7, a1, a2, a3, a4, a5, a6, a7, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		cin >> ch6;
		cin >> ch7;
		terminal3F:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		cin >> a6;
		cin >> a7;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==8) {
		float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, a1, a2, a3, a4, a5, a6, a7, a8, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		cin >> ch6;
		cin >> ch7;
		cin >> ch8;
		terminal3G:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		cin >> a6;
		cin >> a7;
		cin >> a8;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==9) {
		float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, a1, a2, a3, a4, a5, a6, a7, a8, a9, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		cin >> ch6;
		cin >> ch7;
		cin >> ch8;
		cin >> ch9;
		terminal3H:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		cin >> a6;
		cin >> a7;
		cin >> a8;
		cin >> a9;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8) + (ch9 * a9)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9);
		cout << " Weighted mean is : " << r << "\n";
	} else if (IC==10) {
		float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, r;
		cout << " What are the designated points of each choices? \n";
		cin >> ch1;
		cin >> ch2;
		cin >> ch3;
		cin >> ch4;
		cin >> ch5;
		cin >> ch6;
		cin >> ch7;
		cin >> ch8;
		cin >> ch9;
		cin >> ch10;
		terminal3I:
		cout << " What are the answers of each choices? \n";
		cin >> a1;
		cin >> a2;
		cin >> a3;
		cin >> a4;
		cin >> a5;
		cin >> a6;
		cin >> a7;
		cin >> a8;
		cin >> a9;
		cin >> a10;
		r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8) + (ch9 * a9) + (ch10 * a10)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10);
		cout << " Weighted mean is : " << r << "\n";
	}
	cout << " Would you like to continue or exit? \n";
	cout << " 1 = New set \n";
	cout << " 2 = New number of choices \n";
	cout << " 3 = New answers only \n";
	cout << " Any number aside from above = Exit \n";
	cin >> st;
	cout << " \n ";
	switch (st){
 	case 1 :
 		goto terminal1;
 	break;
 	case 2 :
 		goto terminal2;
 	break;
 	case 3 :
 		switch(IC) {
 			case 2:
 				goto terminal3A;
 			break;
 			case 3:
 				goto terminal3B;
 			break;
 			case 4:
 				goto terminal3C;
 			break;
 			case 5:
 				goto terminal3D;
 			break;
 			case 6:
 				goto terminal3E;
 			break;
 			case 7:
 				goto terminal3F;
 			break;
 			case 8:
 				goto terminal3G;
 			break;
 			case 9:
 				goto terminal3H;
 			break;
 			case 10:
 				goto terminal3I;
 			break;
		 }
 	break;
 	default :
 		// do nothing,autmatically breaks the loop.
 	break;
 }
 cout << " Code and Application by Khian Victory D. Calderon \n";
 system("pause");
}
