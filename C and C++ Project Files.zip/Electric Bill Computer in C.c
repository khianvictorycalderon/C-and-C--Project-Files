#include <stdio.h>
#include <string.h>
float kwh, bill; //speaks for itself
char ch[1]; //choice
int main() {
	printf("\nElectric bill computer \n");
	loop:
	printf("What would you like to solve? \n");
	printf("a. Kilowatts Per Hour (KWH) \n");
	printf("b. Electric Bill \n");
	scanf("%s",ch);
	if(strcmp(ch,"a")==0) {
		printf("How much is your bill in pesos in the last 31 Days? \n");
        scanf("%f",&bill);
        kwh = bill / 10.58f;
        printf("You have used about %f KWH in the last 31 Days \n",kwh);
	} else if(strcmp(ch,"b")==0) {
		printf("How much Kilowatt did you used in the last 31 Days? \n");
	    scanf("%f",&kwh);
	    bill = kwh * 10.58f;
	    printf("Your bill is about %f pesos in the last 31 Days \n",bill);
	} else {
		printf("Invalid Input, a or b only!, Try again! \n");
		goto loop;
	}
	system("pause ");
}
