#include <stdio.h>
#include <Math.h>
double a, b, c, r1, r2;

int main() {
	printf("Quadratic Computer in C \nBy Khian Victory D. Calderon \n\n");
	printf("Enter the 3 input from the quadratic equation: \n");
	scanf("%lf",&a);
	scanf("%lf",&b);
	scanf("%lf",&c);
	r1 = ((b * -1) + sqrt((b * b) - (4 * a * c))) / (2 * a);
    r2 = ((b * -1) - sqrt((b * b) - (4 * a * c))) / (2 * a);
    printf("The 2 answers from the quadratic equation are: \n");
    printf("%lf and %lf \n",r1,r2);
	system("pause");
}
