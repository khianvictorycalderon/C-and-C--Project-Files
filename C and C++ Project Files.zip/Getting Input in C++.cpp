#include <iostream>
using namespace std;

// variables
int x;
int y;

int main() {
	cout << "Enter integer input \n";
	cout << "**Similar to scanf in C** \n";
	cin >> x;
	cout << "Enter another integer input \n";
	cin >> y;
	cout << "You have entered " << x << " and " << y << " integers \n";
	system("pause");
	return 0;
}
