#include <iostream>
using namespace std;
float bill,cum;
string ch;

int main() {
	cout << "\nWater Bill Computer \n";
	loop:
	cout << "What will compute? (Residential Type Only) \n";
	cout << "a. Cubic Per Meter (CUM) \n";
	cout << "b. Water Bill \n";
	cin >> ch;
	if(ch=="a") {
		cout << "How much is your bill in pesos in the last 31 Days without tax? \n";
	    cin >> bill;
	    cum = bill / 21;
	    cout << "You used about "<<cum<<" Cubic Meter of Water in 31 Days \n";
	} else if (ch=="b") {
		cout << "How much Cubic Meter of Water did you used in the last 31 Days? \n";
		cin >> cum;
		bill = cum * 21;
		cout << "Your water bill is about "<<bill + ((bill * 12)/100)<<" pesos in 31 Days on DUE with tax included \n";
	} else {
		cout << "Invalid Input, try again! a or b only! \n";
		goto loop;
	}
	system("pause");
}
