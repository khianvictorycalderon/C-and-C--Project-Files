#include <iostream>
using namespace std;
float bill,kwh;
string ch;

int main() {
	cout << "\nElectric Bill Computer \n";
	loop:
	cout << "What would you like to compute? \n";
	cout << "a. Kilowatts \n";
	cout << "b. Electrical bill \n";
	cin >> ch;
	if(ch=="a") {
		cout << "How much is your electrical bill in pesos in the last 31 Days? \n";
	    cin >> bill;
	    kwh = bill / 10.58;
	    cout << "You have used around "<<kwh<<" of electricity in the last 31 Days \n";
	} else if (ch=="b") {
		cout << "How much Kilowatts did you used in the last 31 Days? \n";
		cin >> kwh;
		bill = kwh * 10.58;
		cout << "Your bill is around "<<bill<<" pesos in the last 31 Days \n";
	} else {
		cout << "Invalid Input, try again! a or b only! \n";
		goto loop;
	}
	system("pause");
}
