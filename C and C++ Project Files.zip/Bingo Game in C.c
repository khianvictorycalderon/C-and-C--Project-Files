#include <stdio.h> // If else if Conditional Structure
int input; // Code made by Khian Victory D. Calderon
int main() {
	printf("Hello People! , This is a BINGO Game!"); 
	printf("\n Please enter a number between 1 to 75 \n \n");
	scanf("%d",&input);
	if(input>=1 && input<=75){ 
	if (input>=1 && input<=15){printf("\n B \n");}
	else if(input>=16 && input<=30){printf("\n I \n");}
	else if(input>=31 && input<=45){printf("\n N \n");}
	else if(input>=46 && input<=60){printf("\n G \n");}
	else if(input>=61 && input<=75){printf("\n O \n");}
	} else {printf("\n PROGRAM CRASHED \n");
	printf(" Fault : Invalid Input \n");
	printf(" Recomended Action : Restart the Program \n");
	}
	system("pause" );
}
