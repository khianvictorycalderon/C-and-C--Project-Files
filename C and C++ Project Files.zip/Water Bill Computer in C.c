#include <stdio.h>
#include <string.h>
float cum, bill; //speaks for itself
char ch[1]; //choice
int main() {
	printf("\nWater bill computer \n");
	loop:
	printf("What will compute? (Residential Type Only) \n");
	printf("a. Cubic Per Meter (CUM) \n");
	printf("b. Water Bill \n");
	scanf("%s",ch);
	if(strcmp(ch,"a")==0) {
 		printf("How much is your bill in pesos in the last 31 Days without tax? \n");
        scanf("%f",&bill);
        cum = bill / 21.0f;
        printf("You used about %f Cubic Meter of Water in 31 Days \n",cum);
	} else if(strcmp(ch,"b")==0) {
		printf("How much Cubic Meter of Water did you used in the last 31 Days? \n");
	    scanf("%f",&cum);
	    bill = cum * 21.0f;
	    printf("Your water bill is about %f pesos in 31 Days on DUE with tax included \n",bill + ((bill * 12)/100));
	} else {
		printf("Invalid Input, a or b only!, Try again! \n");
		goto loop;
	}
	system("pause ");
}
