#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int random;

int main () {
   printf("\n Press enter to generate a random value between 1 - 3 \n");
   getchar();
   srand(time(NULL)*3);
   random = ((rand() % 3));
   if(random==0) {
   	printf("Random 1 \n");
   } else if (random==1) {
   	printf("Random 2 \n");
   } else {
   	printf("Random 3 \n");
   }
   system("pause");
}


