#include <iostream>
using namespace std;
int main() {
	cout << "Output 1 \n";
	cout << "Output 2 \n";
	cout << "Last Output (3) \n";
	cin.get();
	return 0;
}
