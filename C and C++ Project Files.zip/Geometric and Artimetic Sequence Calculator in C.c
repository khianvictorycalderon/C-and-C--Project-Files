#include <stdio.h>
float num1,num2,num3,cv,cr;
// cv is common value for arithmetic sequence
// cr is common ratio for geometric sequence
int main() {
 printf("\nGeometric and Arithmetic Sequence Calculator \n");
 printf("This program will determine if it is arithmetic or geometric sequence and its previous and next term \n");
 printf("Enter three input: \n");
 scanf("%f",&num1);
 scanf("%f",&num2);
 scanf("%f",&num3);
 cv = num2-num1; // common value of arithmetic sequence
 cr = num2/num1; // common ratio of geometric sequence
 if(cr == 1 && cv == 0) { // arithmetic or geometric sequence
 	printf("The sequence is either geometric or arithmetic \n");
    printf("Common Value is %.2f \n",cv);
    printf("Common Ratio is %.2f \n",cr);
    printf("The following sequence are: \n");
    printf("%.2f,%.2f,%.2f,%.2f,%.2f \n",num1/cr,num1,num2,num3,num3+cv);
 } else if (num2-num1 == num3-num2) { //arithmetic sequence
 	printf("It is an Arithmetic Sequence \n");
 	printf("Common Value is %.2f \n",cv);
 	printf("The following sequence are: \n");
 	printf("%.2f,%.2f,%.2f,%.2f,%.2f \n",num1-cv,num1,num2,num3,num3+cv);
 } else if (num2/num1 == num3/num2) { //geometric sequence
 	printf("It is a Geometric Sequence \n");
 	printf("Common Ratio is %.2f \n",cr);
 	printf("The following sequence are: \n");
 	printf("%.2f,%.2f,%.2f,%.2f,%.2f \n",num1/cr,num1,num2,num3,num3*cr);
 } else { // neither geometric or arithmetic sequence
 	printf("The sequence is neither geometric nor arithmetic \n");
 }
 system("pause");
}
