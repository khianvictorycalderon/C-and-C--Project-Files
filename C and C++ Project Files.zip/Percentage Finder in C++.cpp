#include <iostream>
using namespace std;
float n,p,f;
int main() {
 cout << "\nEnter Percentage: \n";
 cin >> p;
 cout << "Enter Number: \n";
 cin >> n;
 f = (n*p)/100.0f;
 cout << p<<"% of "<<n<<" is "<<f;
 system("pause");
}
