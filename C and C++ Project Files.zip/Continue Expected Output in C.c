#include <stdio.h>
int main()
{
   int i = 100;
   do {
   	i--;
   	  if(i>50&&i<60)
   	  {
   	  	continue;
	  }
	 printf("%d \n",i);
   } while (i>1);
   system("pause");
}
