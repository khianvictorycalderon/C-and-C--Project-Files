#include<iostream>
using namespace std;
float num1,num2,num3,cv,cr;
// cv is common value for arithmetic sequence
// cr is common ratio for geometric sequence
int main() {
 cout << "\nGeometric and Arithmetic Sequence Calculator \n";
 cout << "This program will determine if it is arithmetic or geometric sequence and its previous and next term \n";
 cout << "Enter three input: \n";
 cin >> num1;
 cin >> num2;
 cin >> num3;
 cv = num2-num1; // common value of arithmetic sequence
 cr = num2/num1; // common ratio of geometric sequence
 if(cr == 1 && cv == 0) { // arithmetic or geometric sequence
 	cout << "The sequence is either geometric or arithmetic \n";
 	cout << "Common Value is " << cv << "\n";
 	cout << "Common Ratio is " << cr << "\n";
 	cout << "The following sequence are: \n";
 	cout << num1/cr << ",";
 	cout << num1 << ",";
 	cout << num2 << ",";
 	cout << num3 << ",";
 	cout << num3+cv;
 	cout << "\n";
 } else if (num2-num1 == num3-num2) { //arithmetic sequence
 	cout << "It is an Arithmetic Sequence \n";
 	cout << "Common Value is " << cv << "\n";
 	cout << "The following sequence are: \n";
 	cout << num1-cv << ",";
 	cout << num1 << ",";
 	cout << num2 << ",";
 	cout << num3 << ",";
 	cout << num3+cv;
 	cout << "\n";
 } else if (num2/num1 == num3/num2) { //geometric sequence
 	cout << "It is a Geometric Sequence \n";
 	cout << "Common Ratio is " << cr << "\n";
 	cout << "The following sequence are: \n";
 	cout << num1/cr << ",";
 	cout << num1 << ",";
 	cout << num2 << ",";
 	cout << num3 << ",";
 	cout << num3*cr;
 	cout << "\n";
 } else { // neither geometric or arithmetic sequence
 	cout << "The sequence is neither geometric nor arithmetic \n";
 }
 system("pause");
}
