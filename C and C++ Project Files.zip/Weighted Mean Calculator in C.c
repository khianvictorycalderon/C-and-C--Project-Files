#include <stdio.h>
int IC; // Input Count, How many inputs? how many choices?
int st; // status, if the user want to do it again or exit
int main() {
 printf("\n Weighted Mean Calculator Table in C \n");
 printf(" by Khian Victory D. Calderon \n");
 terminal1 :
 printf(" How many choices in the questions? (2 - 10 Only) \n");
 scanf("%d",&IC);
 terminal2 :
 if(IC==2) {
 	float ch1, ch2, a1, a2, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	terminal3A:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	r = ((ch1 * a1) + (ch2 * a2)) / (a1 + a2);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==3) {
 	float ch1, ch2, ch3, a1, a2, a3, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	terminal3B:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3)) / (a1 + a2 + a3);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==4) {
 	float ch1, ch2, ch3, ch4, a1, a2, a3, a4, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	terminal3C:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4)) / (a1 + a2 + a3 + a4);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==5) {
 	float ch1, ch2, ch3, ch4, ch5, a1, a2, a3, a4, a5, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	terminal3D:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5)) / (a1 + a2 + a3 + a4 + a5);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==6) {
 	float ch1, ch2, ch3, ch4, ch5, ch6, a1, a2, a3, a4, a5, a6, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	scanf("%f",&ch6);
 	terminal3E:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	scanf("%f",&a6);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6)) / (a1 + a2 + a3 + a4 + a5 + a6);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==7) {
 	float ch1, ch2, ch3, ch4, ch5, ch6, ch7, a1, a2, a3, a4, a5, a6, a7, r;
 	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	scanf("%f",&ch6);
 	scanf("%f",&ch7);
 	terminal3F:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	scanf("%f",&a6);
 	scanf("%f",&a7);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==8) {
 	float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, a1, a2, a3, a4, a5, a6, a7, a8, r; 	
	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	scanf("%f",&ch6);
 	scanf("%f",&ch7);
 	scanf("%f",&ch8);
 	terminal3G:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	scanf("%f",&a6);
 	scanf("%f",&a7);
 	scanf("%f",&a8);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==9) {
 	float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, a1, a2, a3, a4, a5, a6, a7, a8, a9, r;
	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	scanf("%f",&ch6);
 	scanf("%f",&ch7);
 	scanf("%f",&ch8);
 	scanf("%f",&ch9);
 	terminal3H:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	scanf("%f",&a6);
 	scanf("%f",&a7);
 	scanf("%f",&a8);
 	scanf("%f",&a9);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8) + (ch9 * a9)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9);
 	printf(" Weighted mean is : %.2f \n",r);
 } else if (IC==10) {
 	float ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, r;
	printf(" What are the designated points of each choices? \n");
 	scanf("%f",&ch1);
 	scanf("%f",&ch2);
 	scanf("%f",&ch3);
 	scanf("%f",&ch4);
 	scanf("%f",&ch5);
 	scanf("%f",&ch6);
 	scanf("%f",&ch7);
 	scanf("%f",&ch8);
 	scanf("%f",&ch9);
 	scanf("%f",&ch10);
 	terminal3I:
 	printf(" What are the answers of each choices? \n");
 	scanf("%f",&a1);
 	scanf("%f",&a2);
 	scanf("%f",&a3);
 	scanf("%f",&a4);
 	scanf("%f",&a5);
 	scanf("%f",&a6);
 	scanf("%f",&a7);
 	scanf("%f",&a8);
 	scanf("%f",&a9);
 	scanf("%f",&a10);
 	r = ((ch1 * a1) + (ch2 * a2) + (ch3 * a3) + (ch4 * a4) + (ch5 * a5) + (ch6 * a6) + (ch7 * a7) + (ch8 * a8) + (ch9 * a9) + (ch10 * a10)) / (a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10);
 	printf(" Weighted mean is : %.2f \n",r);
 }
 printf(" Would you like to continue or exit? \n");
 printf(" 1 = New set \n");
 printf(" 2 = New number of choices \n");
 printf(" 3 = New answers only \n");
 printf(" Any number aside from above = Exit \n");
 scanf("%d",&st);
 printf(" \n ");
 switch (st){
 	case 1 :
 		goto terminal1;
 	break;
 	case 2 :
 		goto terminal2;
 	break;
 	case 3 :
 		switch(IC) {
 			case 2:
 				goto terminal3A;
 			break;
 			case 3:
 				goto terminal3B;
 			break;
 			case 4:
 				goto terminal3C;
 			break;
 			case 5:
 				goto terminal3D;
 			break;
 			case 6:
 				goto terminal3E;
 			break;
 			case 7:
 				goto terminal3F;
 			break;
 			case 8:
 				goto terminal3G;
 			break;
 			case 9:
 				goto terminal3H;
 			break;
 			case 10:
 				goto terminal3I;
 			break;
		 }
 	break;
 	default :
 		// do nothing,autmatically breaks the loop.
 	break;
 }
 printf(" Code and Application by Khian Victory D. Calderon \n");
 system("pause");
}
