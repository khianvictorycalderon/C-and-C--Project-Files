#include <iostream>
using namespace std;
float in1;
string op;
float in2;
float result;
int main () {
	scanAgain1 : 
	cout << " \n Enter your first input \n";
	cin >> in1;
	if (in1<0 || in1>0 || in1==0 || in1<1 || in1>-1) {} else {
		goto scanAgain1;
	}
	
	scanAgain2 : 
	cout << " Enter the operation to be used \n";
	cout << " Accepted inputs includes : \n";
	cout << " + for addition \n";
	cout << " - for subtraction \n";
	cout << " * for multiplication \n";
	cout << " / for division \n";
	cout << " % to get the remainder \n";
	cin >> op;
	if (op=="+" || op=="-" || op=="*" || op=="/" || op=="%") {} else {
		goto scanAgain2;
	}
	
	scanAgain3 : 
	cout << " Enter your last input \n";
	cin >> in2;
	if (in2<0 || in2>0 || in2==0 || in2<1 || in2>-1) {} else {
		goto scanAgain3;
	}
	
    if (op=="+") {
    	result = in1 + in2;
	    cout << " " << in1 << " Plus " << in2 << " is " << result;
	} else if (op=="-") {
		result = in1 - in2;
	    cout << " " << in1 << " Minus " << in2 << " is " << result;
	} else if (op=="*") {
		result = in1 * in2;
	   	cout << " " << in1 << " Times " << in2 << " is " << result;
	} else if (op=="/") {
		result = in1 / in2;
	   	cout << " " << in1 << " Divided by " << in2 << " is " << result;
	} else if (op=="%") {
		int result2 = in1 / in2;
	   	cout << " " << in1 << " Divided by " << in2 << " has a remainder of " << " is " << result2;
	}
	cout << "\n";
	system("pause");
	return 0;
}
