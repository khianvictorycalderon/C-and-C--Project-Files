#include<stdio.h>
int input;
int method;
int result;
int main()
{
    printf("Enter your input \n");
    scanf("%d",&input);
    printf("\n Which method do you want to used? \n");
    printf("Enter 1 for Celsius to Fahrenheit \n");
    printf("Enter 2 for Fahrenheit to Celsius \n");
    scanf("%d",&method);
    if(method==1)
    {
        result = (input * 1.8) + 32;
        printf("%d celsius is equal to %d fahrenheit \n", input, result);
    } else if (method==2)
    {
        result = (input - 32) / 1.8;
        printf("%d fahrenheit is equal to %d celsius \n", input, result);
    } else {
        printf("Sorry invalid input , please restart the program \n");
        return 1;
    }
    system("pause" );
}
