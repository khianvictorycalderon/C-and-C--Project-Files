#include <stdio.h>
#include <string.h>
int main()
{
	printf("Enter cheese or not \n");
	char x[30];
    scanf("%s",x);
	if (strcmp(x,"cheese")==0)
    {
         printf("You like cheese too! \n");
    }
    else
    {
         printf("I like cheese more. \n");
    } 
    system("pause");
}
