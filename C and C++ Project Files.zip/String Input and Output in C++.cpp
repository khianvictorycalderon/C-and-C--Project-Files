#include <iostream>
using namespace std;

string text;

int main() {
	
	cout << "Enter a string input \n";
	cin >> text;
	cout << "Your input Text is " << text << "\n \n";
	
	system("pause");
	return 0;
}
