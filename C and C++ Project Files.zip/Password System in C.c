#include <stdio.h>
#include <string.h>
char pass[];
int main() {
	printf("\nEnter 1234 as password \n");
	scanf("%s",pass);
	if(strcmp(pass,"1234")==0) {
		printf("Password is Correct \n");
	} else {
		printf("Password is Incorrect \n");
	}
	system("pause");
}
