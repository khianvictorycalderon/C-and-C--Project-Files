#include <stdio.h>
int z = 1;//code by khian victory d. calderon
int main()
{
	printf("Press enter to print the output");
	getchar(); // wait for user's request
	printf("\n");
	while(z<20)
	{
		printf("%d \n",z);
		z += 2;
	}
	getchar(); //prevent the console from closing
}
