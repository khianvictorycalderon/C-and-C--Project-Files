#include <stdio.h>
int y;
main()
{
	while(1) {
	printf("Enter a 0 input \n");
	scanf("%d",&y);
	 if(y==0)
	 {
	 printf("Success! \n");
	 break;	
     }
	}
	system("pause");
}
