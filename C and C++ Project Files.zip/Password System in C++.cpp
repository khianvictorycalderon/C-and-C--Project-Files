#include <iostream>
using namespace std;
string pass;
int main() {
	cout << "\nEnter 1234 password \n";
	cin >> pass;
	if(pass=="1234") {
	 cout << "Password is Correct";
	} else {
	 cout << "Password is Incorrect";
	}
	system("pause");
}
