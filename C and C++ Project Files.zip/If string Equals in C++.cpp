#include <iostream>
using namespace std;

 string input;

int main () {
	
	cout << "Yes or No? \n";
	cout << "**Any other input will be rejected** \n";
	read : 
	cin >> input;
	if (input=="Yes") {
		cout << "You entered Yes \n";
	} else if (input=="No"){
		cout << "You entered No \n";
	} else {
		cout << "Sorry invalid input , try again \n";
		goto read;
	}
	
	system("pause");
}
