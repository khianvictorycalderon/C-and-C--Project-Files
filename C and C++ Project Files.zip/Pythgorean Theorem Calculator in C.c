#include <stdio.h>
#include <math.h>
#include <string.h>
float leg1,leg2,h;
char c[1]; // choices
int main() {
 begin:
 printf("\nWhat would you like to solve? \n");
 printf("a. Hypotenuse \n");
 printf("b. Legs \n");
 scanf("%s",c);
 if(strcmp(c,"a")==0) {
  printf("Enter leg 1 value: \n");
  scanf("%f",&leg1);
  printf("Enter leg 2 value: \n");
  scanf("%f",&leg2);
  h = sqrt((leg1 * leg1) + (leg2 * leg2));
  printf("The hypotenuse is %.2f \n",h);
 } else if (strcmp(c,"b")==0) {
  printf("Enter Hypotenuse value: \n");
  scanf("%f",&h);
  printf("Enter leg 1 value: \n");
  scanf("%f",&leg1);
  leg2 = sqrt((h * h) - (leg1 * leg1));
  printf("The missing leg is %.2f \n",leg2);
 } else {
  printf("Invalid Input, a or b only! \n");
  goto begin;
 }
 system("pause");
}
